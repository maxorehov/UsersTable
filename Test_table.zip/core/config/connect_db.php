<?php

return [
    'host' => 'mysql:host=localhost;dbname=test_encomage_db;charset=utf8',
    'login' => 'root',
    'pass' => '',
    'props' => [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
];
